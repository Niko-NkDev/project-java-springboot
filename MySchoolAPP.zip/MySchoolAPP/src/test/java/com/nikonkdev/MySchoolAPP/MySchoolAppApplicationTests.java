package com.nikonkdev.MySchoolAPP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySchoolAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
